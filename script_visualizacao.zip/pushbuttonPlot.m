% 01: inductor number 
% 02: core
% 03: wire
% 04: gap
% 05: maximum number of turns
% 06: minimum number of turns
% 07: max fill factor
% 08: min fill factor
% 09: maximum mass
% 10: minimum mass
% 11: maximum resistance
% 12: minimum resistance
% 13: maximum Q
% 14: minimum Q
% 15: maximum Bpk
% 16: minimum Bpk
% 17: maximum price
% 18: minimum price
% 19: maximum volume
% 20: minimum volume
% 21: maximum power  
% 22: minimum power 
% 23: maximum temperature
% 24: minimum temperature

function pushbuttonPlot(localVetOptimum)
 
    f = figure('Position',[50,50,1300,950]);
    
    ax = axes(f);
    ax.Units = 'pixels';
    ax.Position = [150 150 1000 700];
    
    c = uicontrol('Position',[1170,150,120,25]);
    c.String = 'PLOT NOW!';
    c.Callback = @plotButtonPushed;
    
    uicontrol('Style','text','String','in Y axis','Position',[1170,215,120,25]);
    hpopup1 = uicontrol('Style','popupmenu','String', ...
        {'Inductor Number','Core Number','Wire Number', 'Gap lenght', 'Maximum Number of Turns' ...
        'Minimum Number of Turns', 'Maximum Fill Factor', 'Minimum Fill Factor', 'Maximum mass', ...
        'Minimum mass', 'Maximum resistance', 'Minimum Resistance', 'Maximum Q', 'Minimum Q', ...
        'Maximum Bpk', 'Minimum Bpk', 'Maximum price', 'Minimum price', 'Maximum volume', ...
        'Minimum volume', 'Maximum power', 'Minimum power', 'Maximum temperature', ...
        'Minimum temperature'} ,'Position',[1170,250,120,25]);

    uicontrol('Style','text','String','in X axis','Position',[1170,275,120,15]);
    hpopup2 = uicontrol('Style','popupmenu','String', ...
       {'Inductor Number','Core Number','Wire Number', 'Gap lenght', 'Maximum Number of Turns' ...
       'Minimum Number of Turns', 'Maximum Fill Factor', 'Minimum Fill Factor', 'Maximum mass', ...
       'Minimum mass', 'Maximum resistance', 'Minimum Resistance', 'Maximum Q', 'Minimum Q', ...
       'Maximum Bpk', 'Minimum Bpk', 'Maximum price', 'Minimum price', 'Maximum volume', ...
       'Minimum volume', 'Maximum power', 'Minimum power', 'Maximum temperature', ...
       'Minimum temperature'} ,'Position',[1170,200,120,25]);
    
    function plotButtonPushed(src,event)
        cx1 = get(hpopup1, 'Value');
        cx2 = get(hpopup2, 'Value');
        s2 = scatter3(localVetOptimum(:,cx1),localVetOptimum(:,cx2), localVetOptimum(:,1), 'filled');
        s2.MarkerEdgeColor = 'k';
        zlabel('Inductor Number');
        
        %s = scatter(localVetOptimum(:,cx1),localVetOptimum(:,cx2), 'filled');
        %s.MarkerEdgeColor = 'k';
        
        grid on;
        set(gca,'FontSize',28);
        
        if(cx1 == 1)
            xlabel('Inductor number');
        elseif(cx1 == 2)
            xlabel('Core number');
        elseif(cx1 == 3)
            xlabel('Wire number');
        elseif(cx1 == 4)
            xlabel('Gap lenght [m]');
        elseif(cx1 == 5)
            xlabel('Maximum number of turns');
        elseif(cx1 == 6)
            xlabel('Minimum number of turns');
        elseif(cx1 == 7)
            xlabel('Maximum fill factor [%]');
        elseif(cx1 == 8)
            xlabel('Minimum fill factor [%]');
        elseif(cx1 == 9)
            xlabel('Maximum mass [g]');
        elseif(cx1 == 10)
            xlabel('Minimum mass [g]');
        elseif(cx1 == 11)
            xlabel('Maximum resistence [\Omega]');
        elseif(cx1 == 12)
            xlabel('Minimum resistence [\Omega]');
        elseif(cx1 == 13)
            xlabel('Maximum Q');
        elseif(cx1 == 14)
            xlabel('Minimum Q');
        elseif(cx1 == 15)
            xlabel('Maximum Bpk [T]');
        elseif(cx1 == 16)
            xlabel('Minimum Bpk [T]');
        elseif(cx1 == 17)
            xlabel('Maximum price [$]');
        elseif(cx1 == 18)
            xlabel('Minimum price [$]');
        elseif(cx1 == 19)
            xlabel('Maximum volume [m^3]');
        elseif(cx1 == 20)
            xlabel('Minimum volume [m^3]');
        elseif(cx1 == 21)
            xlabel('Maximum power dissipated [W]');
        elseif(cx1 == 22)
            xlabel('Minimum power dissipated [W]');
        elseif(cx1 == 23)
            xlabel('Maximum Temperature [�C]');
        elseif(cx1 == 24)
            xlabel('Minimum Temperature [�C]');
        end
        
        if(cx2 == 1)
            ylabel('Inductor number');
        elseif(cx2 == 2)
            ylabel('Core number');
        elseif(cx2 == 3)
            ylabel('Wire number');
        elseif(cx2 == 4)
            ylabel('Gap lenght [m]');
        elseif(cx2 == 5)
            ylabel('Maximum number of turns');
        elseif(cx2 == 6)
            ylabel('Minimum number of turns');
        elseif(cx2 == 7)
            ylabel('Maximum fill factor [%]');
        elseif(cx2 == 8)
            ylabel('Minimum fill factor [%]');
        elseif(cx2 == 9)
            ylabel('Maximum mass [g]');
        elseif(cx2 == 10)
            ylabel('Minimum mass [g]');
        elseif(cx2 == 11)
            ylabel('Maximum resistence [\Omega]');
        elseif(cx2 == 12)
            ylabel('Minimum resistence [\Omega]');
        elseif(cx2 == 13)
            ylabel('Maximum Q');
        elseif(cx2 == 14)
            ylabel('Minimum Q');
        elseif(cx2 == 15)
            ylabel('Maximum Bpk [T]');
        elseif(cx2 == 16)
            ylabel('Minimum Bpk [T]');
        elseif(cx2 == 17)
            ylabel('Maximum price [$]');
        elseif(cx2 == 18)
            ylabel('Minimum price [$]');
        elseif(cx2 == 19)
            ylabel('Maximum volume [m^3]');
        elseif(cx2 == 20)
            ylabel('Minimum volume [m^3]');
        elseif(cx2 == 21)
            ylabel('Maximum power dissipated [W]');
        elseif(cx2 == 22)
            ylabel('Minimum power dissipated [W]');
        elseif(cx2 == 23)
            ylabel('Maximum Temperature [�C]');
        elseif(cx2 == 24)
            ylabel('Minimum Temperature [�C]');
        end
    end
end